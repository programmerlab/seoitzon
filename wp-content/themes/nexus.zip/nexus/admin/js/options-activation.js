/**
 * Prints out the inline javascript needed for the colorpicker and choosing
 * the tabs in the panel.
 */

jQuery(document).ready(function($) {

	$(window).find('a[href$="themes.php?page=options-framework"]').trigger( "click" );
	
});	