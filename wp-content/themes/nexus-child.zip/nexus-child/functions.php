<?php
/**
 * Nexus Functions Library
 * Here we will define all functions that will be used on Nexus Child Theme.
 */


/******************************************/ 
/* Add your functions after this */
/******************************************/ 
 
 
/******************************************/ 
/* Add your functions before this */
/******************************************/ 




add_action('after_setup_theme', 'nexus_child_setup' , 11);

function nexus_child_setup(){
 
 /*Add your Hooks , Filters and Theme Support after This*/
 
 
 /*Add your Hooks , Filters and Theme Support before This*/
 
}


?>